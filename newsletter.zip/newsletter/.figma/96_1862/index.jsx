import React from 'react';

import styles from './index.module.scss';

const Component = () => {
  return (
    <div className={styles.a2}>
      <img src="../image/mjbvwnkh-d5hklun.png" className={styles.headerImage} />
      <div className={styles.mainImage}>
        <div className={styles.goalsSection}>
          <div className={styles.chips}>
            <p className={styles.emoji}>💫</p>
            <p className={styles.goalsTitle}>Goals</p>
          </div>
          <div className={styles.missionContainer}>
            <p className={styles.missionTitle}>Team's mission & goals for 2025</p>
            <p className={styles.missionDescription}>
              A year defined by focus, commitment, and results.
            </p>
          </div>
        </div>
        <div className={styles.container2}>
          <div className={styles.container}>
            <p className={styles.icon}>🥇</p>
            <p className={styles.title}>Enhance User-Centric Design</p>
            <p className={styles.subtitle}>
              Strengthen UX processes by integrating research methodologies,
              leveraging data insights, and fostering collaboration.
            </p>
          </div>
          <div className={styles.container}>
            <p className={styles.icon}>🤩</p>
            <p className={styles.title}>Improve Team Effectiveness</p>
            <p className={styles.subtitle}>
              Optimize team productivity by enhancing time management, minimizing
              rework, and streamlining workload management.
            </p>
          </div>
          <div className={styles.goalItem}>
            <p className={styles.icon}>📱</p>
            <p className={styles.title2}>Improve acba digital</p>
            <p className={styles.subtitle}>
              Significantly elevate the app's user experience through data-driven
              design and refined user-focused processes.
            </p>
          </div>
          <div className={styles.goalItem}>
            <p className={styles.icon}>🎨</p>
            <p className={styles.title2}>Establish Design System</p>
            <p className={styles.subtitle}>
              Successfully launch a scalable and comprehensive Design System to
              enhance design consistency and streamline development workflows.
            </p>
          </div>
        </div>
      </div>
      <div className={styles.container11}>
        <div className={styles.statisticsHeaderCont}>
          <div className={styles.chips2}>
            <p className={styles.emoji}>✨</p>
            <p className={styles.goalsTitle}>Our Statistics</p>
          </div>
          <div className={styles.statisticsDescriptio}>
            <p className={styles.missionTitle}>Numbers That Explain the Work</p>
            <p className={styles.subtitle2}>
              Metrics don’t tell the whole story, but they reveal the scale, each
              number reflects time spent learning, adjusting, validating, and
              choosing quality over speed.
            </p>
          </div>
        </div>
        <div className={styles.container10}>
          <div className={styles.container7}>
            <div className={styles.container5}>
              <div className={styles.container3}>
                <p className={styles.title3}>26+</p>
                <p className={styles.subtitle3}>Usability studies</p>
              </div>
              <div className={styles.container4}>
                <p className={styles.title4}>5000 +</p>
                <p className={styles.subtitle3}>Participants</p>
              </div>
              <img src="../image/mjbvwnke-e90s0y8.svg" className={styles.vector} />
            </div>
            <div className={styles.container6}>
              <p className={styles.title5}>4+</p>
              <p className={styles.subtitle4}>Mixpanel Dashboards</p>
            </div>
          </div>
          <div className={styles.container9}>
            <div className={styles.container6}>
              <p className={styles.title5}>30+</p>
              <p className={styles.subtitle4}>Acceptance tests</p>
            </div>
            <div className={styles.container8}>
              <img
                src="../image/mjbvwnke-fuv5yaa.png"
                className={styles.a18374361}
              />
              <p className={styles.title6}>
                Countless
                <br />
                internal reviews&nbsp;
              </p>
              <p className={styles.metricDescription}>
                That enables us to streamline processes and enhance our work.
              </p>
            </div>
          </div>
        </div>
      </div>
      <div className={styles.rectangle7}>
        <div className={styles.goalsSection}>
          <div className={styles.chips}>
            <p className={styles.emoji}>✨</p>
            <p className={styles.goalsTitle}>WOW</p>
          </div>
          <div className={styles.missionContainer}>
            <p className={styles.missionTitle}>How We Improved Our Craft</p>
            <p className={styles.missionDescription}>
              We did not wait for better processes. We built them.
            </p>
          </div>
        </div>
        <div className={styles.container13}>
          <div className={styles.container12}>
            <p className={styles.title7}>Weekly Critiques</p>
            <p className={styles.subtitle5}>
              A consistent ritual that improved our alignment, our reasoning, and
              our ability to challenge ideas without challenging people.
            </p>
          </div>
          <div className={styles.container12}>
            <p className={styles.title7}>Data Driven Decision Making</p>
            <p className={styles.subtitle5}>
              Mixpanel dashboards, structured hypotheses, A/B comparisons, usability
              testing, and clearer assumptions. Less intuition. More evidence.
            </p>
          </div>
          <div className={styles.container12}>
            <p className={styles.title7}>Accessibility Testing</p>
            <p className={styles.subtitle5}>
              Not symbolic, not decorative.
              <br />
              Practical, necessary, and now a stable part of our workflow.
            </p>
          </div>
          <div className={styles.container12}>
            <p className={styles.title7}>Team Growth</p>
            <p className={styles.subtitle5}>
              A more professional, more confident, and more self directed design
              team.
              <br />
              Different personalities, shared standards.
              <br />A team that can disagree without friction and align without
              ceremony.
            </p>
          </div>
        </div>
      </div>
      <div className={styles.container18}>
        <div className={styles.chips3}>
          <p className={styles.emoji}>✨</p>
          <p className={styles.goalsTitle}>Our Favorite Features</p>
        </div>
        <div className={styles.container14}>
          <p className={styles.title8}>Where Ideas Become Powerful Features</p>
          <p className={styles.missionDescription}>
            Tiny improvements, big workflow gains.
          </p>
        </div>
        <div className={styles.container17}>
          <div className={styles.rectangle6}>
            <div className={styles.container15}>
              <img src="../image/mjbvwnkh-rjvmgvh.png" className={styles.image} />
            </div>
            <div className={styles.container16}>
              <p className={styles.title9}>Card component’s swipe</p>
              <p className={styles.subtitle6}>
                Simple, scalable, and perfect for structuring content efficiently.
              </p>
            </div>
          </div>
          <div className={styles.rectangle72}>
            <div className={styles.container15}>
              <img src="../image/mjbvwnkh-nqe6zqd.png" className={styles.image} />
            </div>
            <div className={styles.container16}>
              <p className={styles.title9}>Lightly Spiced</p>
              <p className={styles.subtitle6}>
                Faster, fresher, better looking.
                <br />
                Everyday experience just leveled up.
              </p>
            </div>
          </div>
        </div>
        <p className={styles.title10}>See 50+ more features</p>
      </div>
      <div className={styles.container26}>
        <div className={styles.container19}>
          <div className={styles.chips4}>
            <p className={styles.emoji}>💫</p>
            <p className={styles.goalsTitle}>Better Craft</p>
          </div>
          <div className={styles.statisticsDescriptio}>
            <p className={styles.missionTitle}>
              Take a deep dive into our workflows
            </p>
            <p className={styles.subtitle2}>
              These weren’t just cosmetic updates, they were rebuilt using data,
              testing, and lessons learned.
            </p>
          </div>
        </div>
        <div className={styles.rectangle62}>
          <div className={styles.container22}>
            <div className={styles.container20}>
              <p className={styles.title11}>Payment Hub</p>
              <p className={styles.subtitle7}>
                A unified experience that brought order to the most fragmented part
                of the app.
                <br />
                Clear structure, predictable flows, and a product foundation strong
                enough to scale.
              </p>
            </div>
            <div className={styles.container21}>
              <p className={styles.button}>Dive Deeper</p>
            </div>
          </div>
          <div className={styles.container23}>
            <img src="../image/mjbvwnkh-9akjr9l.png" className={styles.image2} />
          </div>
        </div>
        <p className={styles.title12}>Coming Up: Fresh Redesigns 🚀</p>
        <div className={styles.container25}>
          <div className={styles.rectangle4}>
            <div className={styles.container24}>
              <p className={styles.title11}>Cards’ Redesign</p>
              <p className={styles.subtitle}>
                A modern architecture with fewer distractions and more clarity.
                <br />
                Cleaner visuals, better information hierarchy, and reduced cognitive
                load.
              </p>
            </div>
            <img src="../image/mjbvwnkh-t0f0dvh.png" className={styles.image3} />
          </div>
          <div className={styles.rectangle4}>
            <div className={styles.container24}>
              <p className={styles.title11}>Investment</p>
              <p className={styles.subtitle}>
                A structured place for attention, not interruptions.
                <br />
                Less guessing and more control for users.
              </p>
            </div>
            <img src="../image/mjbvwnki-b0lly99.png" className={styles.image3} />
          </div>
        </div>
      </div>
      <div className={styles.container30}>
        <div className={styles.container28}>
          <div className={styles.chips5}>
            <p className={styles.emoji}>✨</p>
            <p className={styles.goalsTitle}>Fun fact</p>
          </div>
          <div className={styles.container27}>
            <p className={styles.title13}>
              Cats practice
              <br />
              usability testing every day
            </p>
            <p className={styles.subtitle8}>
              If they can’t figure it out, they’ll definitely <br />
              knock it off the table
            </p>
          </div>
        </div>
        <div className={styles.container29}>
          <img src="../image/mjbvwnki-ptlulqy.png" className={styles.image4} />
        </div>
      </div>
      <div className={styles.container33}>
        <img src="../image/mjbvwnki-5b4oawy.png" className={styles.image5} />
        <div className={styles.container31}>
          <p className={styles.missionTitle}>Your feedback helps us grow</p>
          <p className={styles.subtitle9}>
            Rate our team’s work and the newsletter to tell us what inspired you
            <br />
            and what we can improve.
          </p>
        </div>
        <div className={styles.container32}>
          <p className={styles.icon2}>✨</p>
          <p className={styles.title14}>Share Your Thoughts</p>
        </div>
      </div>
      <div className={styles.container35}>
        <div className={styles.image6}>
          <img src="../image/mjbvwnki-o2xzgay.png" className={styles.media} />
        </div>
        <div className={styles.container34}>
          <p className={styles.missionTitle}>Thank You!</p>
          <p className={styles.subtitle10}>
            To everyone who collaborated, challenged, and supported us this year
            thank you.
          </p>
          <p className={styles.subtitle11}>
            &nbsp;We built a lot, learned even more, and we’re just getting started.
          </p>
        </div>
      </div>
    </div>
  );
}

export default Component;
